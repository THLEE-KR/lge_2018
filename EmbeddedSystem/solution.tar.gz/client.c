// gcc client.c packetlib.c /root/wiringPi/wiringPi/softServo.c -o client -lwiringPi -lpthread
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <mcp3422.h>  
#include <wiringPi.h>
#include <softServo.h>

#include "packetlib.h"

#define CDS   400
#define TMP36 401
#define SW1   4
#define SW2   5
#define SERVO 25

int led[8] = {11, 10, 13, 12, 14, 15, 16, 0};
int num[10] = {
	0xFC,
	0x60,
	0xDA,
	0xF2,
	0x66,
	0xB6,
	0xBE,
	0xE0,
	0xFE,
	0xF6,
};

int pin[4] = { 27, 24, 28, 29 };
volatile int is_stopped = 0;
int tmp;
int cds;
int* fnd_value;

void show_digit(int select, int value) {
	int i, j;
	// int *arr = num[value];
	int n = num[value];

	// digitalWrite(select, HIGH); 
	for (i = 1; i <= 3; ++i) {
		digitalWrite(i, i == select);
	}

	for (i = 0; i < 8; ++i) {
		digitalWrite(led[i], n & (1 << (7-i)));  // !!
	}
}

void *fnd_thread(void *arg) {
	int arr[3];
	int i;
	int n;

	while (!is_stopped) {
		i = 0;
		memset(arr, 0, sizeof arr);
		n = fnd_value != NULL ? *fnd_value : 0;
		while (n > 0) {
			arr[i++] = n % 10;
			n /= 10;
		}

		show_digit(1, arr[2]);
		delay(1);
		show_digit(2, arr[1]);
		delay(1);
		show_digit(3, arr[0]);
		delay(1);
	}

	return 0;
}

void init_fnd() {
	int i;
	for (i = 1; i <= 3; ++i) {
		pinMode(i, OUTPUT);
	}

	for (i = 0; i < 8; ++i) {
		pinMode(led[i], OUTPUT);
	}
}

void init_step() {
	int i;
	for (i = 0; i < 4; ++i) {
		pinMode(pin[i], OUTPUT);
	}
}

void on_switch1() {
	printf("on_switch1\n");
	fnd_value = &tmp;
}

void on_switch2() {
	printf("on_switch2\n");
	fnd_value = &cds;
}

void init_switch() {
	pinMode(SW1, INPUT);
	pinMode(SW2, INPUT);
	wiringPiISR(SW1, INT_EDGE_FALLING, on_switch1);
	wiringPiISR(SW2, INT_EDGE_FALLING, on_switch2);
}

int get_temp() {
	int reading = analogRead(TMP36);
	double voltage = reading / 1000.;
	double temp = (voltage - 0.5) * 100;

	return (int)temp;
}

int get_cds() {
	return (int)(analogRead(CDS) / 2048. * 100);
}

void play_servo() {
	int values[10] = { 500, 250, 0, -250, 0, 250, 500, 750, 1000, 750 };
	int i;

	for (i = 0; i < 10 ; ++i) {
		softServoWrite(SERVO, values[i]);
		delay(200);
	}
}

void play_step() {
	int seq[8][4] = {
		{ 1,0,0,1 },
		{ 1,0,0,0 },
		{ 1,1,0,0 },
		{ 0,1,0,0 },
		{ 0,1,1,0 },
		{ 0,0,1,0 },
		{ 0,0,1,1 },
		{ 0,0,0,1 }
	};

	int i, j, k;

	for (i = 0 ; i < 512 ; ++i) {
		for (j = 0; j < 8; ++j) {
			for (k = 0; k < 4; ++k) {
				digitalWrite(pin[k], seq[j][k]);
			}
			delayMicroseconds(800);
		}
	}
}

int main()
{
	pthread_t thread;

	wiringPiSetup();
	init_fnd();
	init_switch();
	init_step();
	softServoSetup(SERVO, -1, -1, -1, -1, -1, -1, -1);

	mcp3422Setup(400, 0x6a, 0, 0); 

	struct sockaddr_in saddr;
	char buf[512];

	int csock = socket(PF_INET, SOCK_STREAM, 0);
	if (csock == -1) {
		perror("socket");
		return 1;
	}

	memset(&saddr, 0, sizeof saddr);
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(5000);
	saddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	if (connect(csock, (struct sockaddr*)&saddr, sizeof saddr) == -1) {
		perror("connect");
		return 1;
	}

	pthread_create(&thread, NULL, fnd_thread, NULL);

	char type = 0;
	char datalen = 0;
	int data;
	while (1) {
		if (type == 0) {
			tmp = data = get_temp();
			tmp = data;
			datalen = sizeof(data);
			if (tmp > 25) {
				play_servo();
			}
		} else if (type == 1) {
			cds = data = get_cds();
			datalen = sizeof(data);
			if (cds > 50) { // 1024
				play_step();
			}
		}

		struct packet packet;
		construct(&packet, buf);

		write_byte(&packet, type);
		write_byte(&packet, datalen);
		write_int32(&packet, data);
		int len = packet_length(&packet);

		write(csock, &len, sizeof len); 
		write(csock, buf, len);

		type = !type;
		delay(1000);
	}

	close(csock);
}

